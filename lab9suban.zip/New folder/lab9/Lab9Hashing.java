/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab9;

/**
 *
 * @author suban
 */



class HashEntry {
    int key;
    String value;
    boolean isDeleted;

    HashEntry(int key, String value) {
        this.key = key;
        this.value = value;
        this.isDeleted = false;
    }
}

class ProbingHashTable {

    private final HashEntry[] table;
    private final int size;
    private final int h2Prime;
    private int count;

    // statistics
    private int insertCollisions;
    private int insertProbes;
    private int lastProbes;

    public ProbingHashTable(int size) {
        this(size, 5);                    // default secondary prime = 5
    }

    public ProbingHashTable(int size, int h2Prime) {
        this.size = size;
        this.h2Prime = h2Prime;
        this.table = new HashEntry[size];
        this.count = 0;
    }

    /* ---------- hash functions ---------- */
    public int h1(int key) {
        return Math.abs(key) % size;
    }

    public int h2(int key) {
        int step = h2Prime - (Math.abs(key) % h2Prime);
        if (step == 0) step = 1;          // h2 must never be 0
        return step;
    }

    private int probeIndex(int key, int i, String mode) {
        int base = h1(key);
        switch (mode.toUpperCase()) {
            case "LINEAR":    return (base + i) % size;
            case "QUADRATIC": return (base + i * i) % size;
            case "DOUBLE":    return (base + i * h2(key)) % size;
            default: throw new IllegalArgumentException("Unknown mode: " + mode);
        }
    }

    /* ---------- insert ---------- */
    public boolean insert(int key, String value, String mode) {
        if (count == size) {
            System.out.println("Table full! Cannot insert key " + key);
            return false;
        }

        int firstDeleted = -1;
        int probes = 0;

        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i, mode);
            probes++;

            if (table[idx] == null) {
                int pos = (firstDeleted != -1) ? firstDeleted : idx;
                table[pos] = new HashEntry(key, value);
                count++;
                finishInsert(probes);
                return true;
            } else if (table[idx].isDeleted) {
                if (firstDeleted == -1) firstDeleted = idx;   // remember tombstone
            } else if (table[idx].key == key) {
                table[idx].value = value;                     // update existing key
                finishInsert(probes);
                return true;
            } else {
                insertCollisions++;                           // probe hit a live key
            }
        }

        if (firstDeleted != -1) {
            table[firstDeleted] = new HashEntry(key, value);
            count++;
            finishInsert(probes);
            return true;
        }
        finishInsert(probes);
        return false;
    }

    private void finishInsert(int probes) {
        insertProbes += probes;
        lastProbes = probes;
    }

    /* ---------- search ---------- */
    public String search(int key, String mode) {
        lastProbes = 0;
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i, mode);
            lastProbes++;
            if (table[idx] == null) return null;                        // never used -> stop
            if (!table[idx].isDeleted && table[idx].key == key) {
                return table[idx].value;
            }
        }
        return null;
    }

    /* ---------- delete (tombstone) ---------- */
    public boolean delete(int key, String mode) {
        lastProbes = 0;
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i, mode);
            lastProbes++;
            if (table[idx] == null) return false;
            if (!table[idx].isDeleted && table[idx].key == key) {
                table[idx].isDeleted = true;    // tombstone, NOT null
                count--;
                return true;
            }
        }
        return false;
    }

    /* ---------- display ---------- */
    public void display() {
        for (int i = 0; i < size; i++) {
            String s;
            if (table[i] == null)               s = "[EMPTY]";
            else if (table[i].isDeleted)        s = "[DELETED]";
            else s = "(" + table[i].key + ", " + table[i].value + ")";
            System.out.printf("Slot %2d: %s%n", i, s);
        }
    }

    /* ---------- getters ---------- */
    public int size()                 { return size; }
    public int count()                { return count; }
    public double loadFactor()        { return (double) count / size; }
    public int getInsertCollisions()  { return insertCollisions; }
    public int getInsertProbes()      { return insertProbes; }
    public int getLastProbes()        { return lastProbes; }
}


/* ============================================================
                        DRIVER / MAIN
   ============================================================ */
public class Lab9Hashing {

    public static void main(String[] args) {
        task1();
        task2();
        task3();
    }

    /* ================= TASK 1 : LINEAR PROBING ================= */
    private static void task1() {
        System.out.println("==================================================");
        System.out.println(" TASK 1 : LINEAR PROBING  (m = 7, h(k) = k % 7)");
        System.out.println("==================================================");

        ProbingHashTable ht = new ProbingHashTable(7);
        int[] keys = {14, 21, 8, 15, 22};

        for (int k : keys) {
            ht.insert(k, "Val_" + k, "LINEAR");
            System.out.println("Insert " + k + "  (h1 = " + ht.h1(k) + ")"
                    + "  -> slots examined = " + ht.getLastProbes());
        }

        System.out.println("\nFinal Table:");
        ht.display();

        System.out.println("\nTotal collisions during insertion : " + ht.getInsertCollisions());
        System.out.println("Total probe steps during insertion: " + ht.getInsertProbes());
        System.out.printf("Load factor                       : %.2f%n", ht.loadFactor());

        System.out.println("\nSearch Results:");
        String r1 = ht.search(15, "LINEAR");
        System.out.println("  Search 15 -> " + (r1 != null
                ? "FOUND (" + r1 + ") in " + ht.getLastProbes() + " probe(s)"
                : "NOT FOUND"));

        String r2 = ht.search(99, "LINEAR");
        System.out.println("  Search 99 -> " + (r2 != null
                ? "FOUND (" + r2 + ") in " + ht.getLastProbes() + " probe(s)"
                : "NOT FOUND (" + ht.getLastProbes() + " probes, stopped at EMPTY slot)"));
    }

    /* ============ TASK 2 : QUADRATIC vs DOUBLE HASHING ========= */
    private static void task2() {
        System.out.println("\n==================================================");
        System.out.println(" TASK 2 : QUADRATIC PROBING vs DOUBLE HASHING");
        System.out.println(" m = 11, h1(k) = k % 11, h2(k) = 7 - (k % 7)");
        System.out.println("==================================================");

        int[] keys = {22, 33, 44, 11, 55};

        // ---- Quadratic ----
        ProbingHashTable q = new ProbingHashTable(11, 7);
        System.out.println("\n--- Quadratic Probing: (h1 + i*i) % 11 ---");
        for (int k : keys) {
            q.insert(k, "Val_" + k, "QUADRATIC");
            System.out.println("Insert " + k + " -> slots examined = " + q.getLastProbes());
        }
        System.out.println("\nQuadratic Final Table:");
        q.display();

        // ---- Double ----
        ProbingHashTable d = new ProbingHashTable(11, 7);
        System.out.println("\n--- Double Hashing: (h1 + i*h2) % 11 ---");
        for (int k : keys) {
            d.insert(k, "Val_" + k, "DOUBLE");
            System.out.println("Insert " + k + " (h1=" + d.h1(k) + ", h2=" + d.h2(k) + ")"
                    + " -> slots examined = " + d.getLastProbes());
        }
        System.out.println("\nDouble Hashing Final Table:");
        d.display();

        System.out.println("\n---------------- COMPARISON ----------------");
        System.out.println("Quadratic : total probes = " + q.getInsertProbes()
                + " , collisions = " + q.getInsertCollisions());
        System.out.println("Double    : total probes = " + d.getInsertProbes()
                + " , collisions = " + d.getInsertCollisions());
        System.out.println("Double hashing needed FEWER probe steps because each key");
        System.out.println("gets its own step size h2(k), spreading keys instead of");
        System.out.println("walking the same i, i^2 sequence (secondary clustering).");
    }

    /* ============== TASK 3 : LOOKUP + TOMBSTONE DELETE ========= */
    private static void task3() {
        System.out.println("\n==================================================");
        System.out.println(" TASK 3 : TOMBSTONE DELETION (DOUBLE HASHING)");
        System.out.println(" m = 7, h1(k) = k % 7, h2(k) = 5 - (k % 5)");
        System.out.println("==================================================");

        ProbingHashTable ht = new ProbingHashTable(7, 5);

        int[]    ks = {12, 19, 26, 5};
        String[] vs = {"Ali", "Sara", "Bilal", "Hina"};

        System.out.println("\n--- Insertions ---");
        for (int i = 0; i < ks.length; i++) {
            ht.insert(ks[i], vs[i], "DOUBLE");
            System.out.println("Insert (" + ks[i] + ", " + vs[i] + ")  h1=" + ht.h1(ks[i])
                    + " h2=" + ht.h2(ks[i]) + " -> slots examined = " + ht.getLastProbes());
        }

        System.out.println("\nTable after insertion:");
        ht.display();

        System.out.println("\n--- Delete key 19 (tombstone) ---");
        boolean ok = ht.delete(19, "DOUBLE");
        System.out.println("Delete 19 -> " + ok + "  (" + ht.getLastProbes() + " probes)");
        System.out.println("\nTable after deleting 19:");
        ht.display();

        System.out.println("\n--- Search key 26 after deletion ---");
        String v = ht.search(26, "DOUBLE");
        System.out.println("Search 26 -> " + (v != null
                ? "FOUND (" + v + ") in " + ht.getLastProbes() + " probe(s)  [probe chain intact]"
                : "NOT FOUND"));

        System.out.println("\nNote: slot 6 is [DELETED], not null, so the probe chain");
        System.out.println("for key 26 is not broken. If we had set it to null, keys");
        System.out.println("inserted further along that chain would become unreachable.");
    }
}
