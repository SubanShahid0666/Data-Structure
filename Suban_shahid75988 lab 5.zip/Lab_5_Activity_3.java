/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    import java.util.Stack;
import java.util.Scanner;
import java.util.Deque;
import java.util.ArrayDeque;

public class Lab_5_Activity_3 {

    // ======================================================
    // 1. CIRCULAR QUEUE
    // ======================================================
    static class CircularQueue {
        private int[] arr;
        private int front, rear, count, capacity;

        CircularQueue(int capacity) {
            this.capacity = capacity;
            arr = new int[capacity];
            front = -1;
            rear = -1;
            count = 0;
        }

        boolean isEmpty() { return count == 0; }
        boolean isFull()  { return count == capacity; }

        void enqueue(int value) {
            if (isFull()) {
                System.out.println("Overflow! Queue is full.");
                return;
            }
            if (isEmpty()) {
                front = 0;
                rear = 0;
            } else {
                rear = (rear + 1) % capacity;
            }
            arr[rear] = value;
            count++;
            System.out.println("Enqueued: " + value);
        }

        int dequeue() {
            if (isEmpty()) {
                System.out.println("Underflow! Queue is empty.");
                return -1;
            }
            int value = arr[front];
            if (count == 1) {
                front = -1;
                rear = -1;
            } else {
                front = (front + 1) % capacity;
            }
            count--;
            System.out.println("Dequeued: " + value);
            return value;
        }

        int peek() {
            if (isEmpty()) {
                System.out.println("Queue is empty.");
                return -1;
            }
            return arr[front];
        }

        void display() {
            if (isEmpty()) {
                System.out.println("Queue is empty.");
                return;
            }
            System.out.print("Queue elements: ");
            int i = front;
            for (int c = 0; c < count; c++) {
                System.out.print(arr[i] + " ");
                i = (i + 1) % capacity;
            }
            System.out.println();
        }
    }

    // ======================================================
    // 2. PRIORITY QUEUE
    // ======================================================
    static class PQItem {
        int value;
        int priority;
        PQItem(int value, int priority) {
            this.value = value;
            this.priority = priority;
        }
    }

    static class SimplePriorityQueue {
        private PQItem[] arr;
        private int size;
        private int capacity;

        SimplePriorityQueue(int capacity) {
            this.capacity = capacity;
            arr = new PQItem[capacity];
            size = 0;
        }

        boolean isEmpty() { return size == 0; }
        boolean isFull()  { return size == capacity; }

        void insert(int value, int priority) {
            if (isFull()) {
                System.out.println("Overflow! Priority Queue is full.");
                return;
            }
            arr[size] = new PQItem(value, priority);
            size++;
            System.out.println("Inserted: value=" + value + ", priority=" + priority);
        }

        PQItem remove() {
            if (isEmpty()) {
                System.out.println("Underflow! Priority Queue is empty.");
                return null;
            }
            int bestIndex = 0;
            for (int i = 1; i < size; i++) {
                if (arr[i].priority < arr[bestIndex].priority) {
                    bestIndex = i;
                }
            }
            PQItem removed = arr[bestIndex];
            for (int i = bestIndex; i < size - 1; i++) {
                arr[i] = arr[i + 1];
            }
            arr[size - 1] = null;
            size--;
            System.out.println("Removed: value=" + removed.value +
                               ", priority=" + removed.priority);
            return removed;
        }

        void display() {
            if (isEmpty()) {
                System.out.println("Priority Queue is empty.");
                return;
            }
            System.out.println("Priority Queue elements:");
            for (int i = 0; i < size; i++) {
                System.out.println("  Value: " + arr[i].value +
                                   ", Priority: " + arr[i].priority);
            }
        }
    }

    // ======================================================
    // 3. DEQUE (using Java's built-in ArrayDeque)
    // ======================================================
    static void dequeMenu(Scanner sc) {
        Deque<Integer> deque = new ArrayDeque<>();
        int choice;

        do {
            System.out.println("\n--- DEQUE MENU ---");
            System.out.println("1. Insert at Front");
            System.out.println("2. Insert at Rear");
            System.out.println("3. Remove from Front");
            System.out.println("4. Remove from Rear");
            System.out.println("5. Peek Front");
            System.out.println("6. Peek Rear");
            System.out.println("7. Display");
            System.out.println("8. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter value: ");
                    deque.addFirst(sc.nextInt());
                    System.out.println("Inserted at front.");
                    break;
                case 2:
                    System.out.print("Enter value: ");
                    deque.addLast(sc.nextInt());
                    System.out.println("Inserted at rear.");
                    break;
                case 3:
                    if (deque.isEmpty()) System.out.println("Deque is empty.");
                    else System.out.println("Removed from front: " + deque.removeFirst());
                    break;
                case 4:
                    if (deque.isEmpty()) System.out.println("Deque is empty.");
                    else System.out.println("Removed from rear: " + deque.removeLast());
                    break;
                case 5:
                    if (deque.isEmpty()) System.out.println("Deque is empty.");
                    else System.out.println("Front: " + deque.peekFirst());
                    break;
                case 6:
                    if (deque.isEmpty()) System.out.println("Deque is empty.");
                    else System.out.println("Rear: " + deque.peekLast());
                    break;
                case 7:
                    if (deque.isEmpty()) System.out.println("Deque is empty.");
                    else System.out.println("Deque: " + deque);
                    break;
                case 8:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 8);
    }

    // ======================================================
    // 4. INFIX TO POSTFIX
    // ======================================================
    static int precedence(char op) {
        switch (op) {
            case '*': case '/': case '%': return 2;
            case '+': case '-': return 1;
            default: return -1;
        }
    }

    static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
    }

    static boolean isOperand(char c) {
        return Character.isLetterOrDigit(c);
    }

    static String infixToPostfix(String expression) {
        StringBuilder output = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (c == ' ') continue;

            if (isOperand(c)) {
                output.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    output.append(stack.pop());
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                }
            } else if (isOperator(c)) {
                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) >= precedence(c)) {
                    output.append(stack.pop());
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            output.append(stack.pop());
        }

        return output.toString();
    }

    // ======================================================
    // MAIN MENU
    // ======================================================
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n========== DATA STRUCTURES LAB 4 ==========");
            System.out.println("1. Circular Queue");
            System.out.println("2. Priority Queue");
            System.out.println("3. Deque");
            System.out.println("4. Infix to Postfix");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                // ---------------- CIRCULAR QUEUE ----------------
                case 1: {
                    System.out.print("Enter circular queue capacity: ");
                    int cap = sc.nextInt();
                    CircularQueue cq = new CircularQueue(cap);
                    int sub;

                    do {
                        System.out.println("\n--- CIRCULAR QUEUE MENU ---");
                        System.out.println("1. Enqueue");
                        System.out.println("2. Dequeue");
                        System.out.println("3. Peek");
                        System.out.println("4. Display");
                        System.out.println("5. Back to Main Menu");
                        System.out.print("Enter choice: ");
                        sub = sc.nextInt();

                        switch (sub) {
                            case 1:
                                System.out.print("Enter value: ");
                                cq.enqueue(sc.nextInt());
                                break;
                            case 2:
                                cq.dequeue();
                                break;
                            case 3:
                                System.out.println("Front element: " + cq.peek());
                                break;
                            case 4:
                                cq.display();
                                break;
                            case 5:
                                System.out.println("Returning to main menu...");
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    } while (sub != 5);
                    break;
                }

                // ---------------- PRIORITY QUEUE ----------------
                case 2: {
                    System.out.print("Enter priority queue capacity: ");
                    int cap = sc.nextInt();
                    SimplePriorityQueue pq = new SimplePriorityQueue(cap);
                    int sub;

                    do {
                        System.out.println("\n--- PRIORITY QUEUE MENU ---");
                        System.out.println("1. Insert");
                        System.out.println("2. Remove");
                        System.out.println("3. Display");
                        System.out.println("4. Back to Main Menu");
                        System.out.print("Enter choice: ");
                        sub = sc.nextInt();

                        switch (sub) {
                            case 1:
                                System.out.print("Enter value: ");
                                int v = sc.nextInt();
                                System.out.print("Enter priority: ");
                                int p = sc.nextInt();
                                pq.insert(v, p);
                                break;
                            case 2:
                                pq.remove();
                                break;
                            case 3:
                                pq.display();
                                break;
                            case 4:
                                System.out.println("Returning to main menu...");
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    } while (sub != 4);
                    break;
                }

                // ---------------- DEQUE ----------------
                case 3:
                    dequeMenu(sc);
                    break;

                // ---------------- INFIX TO POSTFIX ----------------
                case 4: {
                    sc.nextLine(); // consume leftover newline
                    System.out.println("Enter Infix Expression:");
                    String infix = sc.nextLine();

                    String postfix = infixToPostfix(infix);

                    System.out.println();
                    System.out.println("Infix Expression:");
                    System.out.println(infix);

                    System.out.println();
                    System.out.println("Postfix Expression:");
                    System.out.println(postfix);
                    break;
                }

                // ---------------- EXIT ----------------
                case 5:
                    System.out.println("Exiting program. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 5);

        sc.close();
    }
}
    
