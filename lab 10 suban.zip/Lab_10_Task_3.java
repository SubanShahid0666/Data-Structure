/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
class Patient {
    String name;
    int priority;               // 1 = Critical ... 5 = Low

    Patient(String name, int priority) {
        this.name = name;
        this.priority = priority;
    }

    @Override
    public String toString() {
        String label;
        switch (priority) {
            case 1: label = "Critical"; break;
            case 2: label = "Urgent";   break;
            case 3: label = "Moderate"; break;
            case 4: label = "Normal";   break;
            default: label = "Low";     break;
        }
        return "(" + name + ", " + priority + " - " + label + ")";
    }
}

class PatientMinHeap {
    private Patient[] heap;
    private int size;
    private int capacity;

    PatientMinHeap(int capacity) {
        this.capacity = capacity;
        this.heap = new Patient[capacity];
        this.size = 0;
    }

    int parent(int i)     { return (i - 1) / 2; }
    int leftChild(int i)  { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }

    void swap(int i, int j) {
        Patient t = heap[i]; heap[i] = heap[j]; heap[j] = t;
    }

    // Smaller priority number = more urgent = "smaller" in Min Heap terms
    void insert(Patient p) {
        if (size == capacity) { System.out.println("Queue is full!"); return; }
        heap[size] = p;
        int current = size;
        size++;
        while (current > 0 &&
               heap[current].priority < heap[parent(current)].priority) {
            swap(current, parent(current));
            current = parent(current);
        }
    }

    Patient peek() {
        if (size == 0) return null;
        return heap[0];
    }

    Patient extractMin() {
        if (size == 0) return null;
        Patient min = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);
        return min;
    }

    void heapifyDown(int i) {
        int smallest = i;
        int left  = leftChild(i);
        int right = rightChild(i);
        if (left  < size && heap[left].priority  < heap[smallest].priority) smallest = left;
        if (right < size && heap[right].priority < heap[smallest].priority) smallest = right;
        if (smallest != i) { swap(i, smallest); heapifyDown(smallest); }
    }

    void display() {
        if (size == 0) { System.out.println("Queue is empty."); return; }
        for (int i = 0; i < size; i++) System.out.println("  " + heap[i]);
    }

    int getSize() { return size; }
}

public class Lab_10_Task_3 {
    public static void main(String[] args) {
        System.out.println("===== TASK 3: Hospital Emergency Queue (Min Heap) =====\n");

        PatientMinHeap er = new PatientMinHeap(20);

        Patient[] patients = {
            new Patient("Ali",    3),
            new Patient("Sara",   1),
            new Patient("Bilal",  4),
            new Patient("Ayesha", 2),
            new Patient("Usman",  5)
        };

        System.out.println("Inserting patients:");
        for (Patient p : patients) {
            er.insert(p);
            System.out.println("  + " + p);
        }

        System.out.println("\n--- Next patient to be treated (peek) ---");
        System.out.println("  " + er.peek());

        System.out.println("\n--- Treating top 2 most urgent patients ---");
        Patient p1 = er.extractMin();
        System.out.println("  Treated 1st : " + p1);
        Patient p2 = er.extractMin();
        System.out.println("  Treated 2nd : " + p2);

        System.out.println("\n--- Remaining patients waiting (" + er.getSize() + ") ---");
        er.display();
    }
}