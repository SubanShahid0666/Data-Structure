/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
public class facto {
    public static void main(String[] args){
        int n=5;
        int factorial=1;
        for(int i=1;i<=n;i++){
            factorial *=i;
        }
        System.out.println("factorial is :"+factorial);
    }
}
