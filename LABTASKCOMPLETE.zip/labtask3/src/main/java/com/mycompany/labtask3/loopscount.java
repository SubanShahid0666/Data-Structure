
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
public class loopscount {
    public static void main(String[] args){
        int i=10;
        while (i>=1){
       
        System.out.println(i);
        i--;
    }}
}
