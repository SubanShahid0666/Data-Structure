/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
import java.util.Scanner;
public class StopAtMinusOne {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        int count = 0;

        System.out.println("Enter numbers to sum (enter -1 to stop):");

        while (true) { // infinite loop
            System.out.print("Number: ");
            int num = scanner.nextInt();

            if (num == -1) {
                break; // exit loop immediately
            }

            sum += num;
            count++;
        }

        System.out.println("You entered " + count + " numbers.");
        System.out.println("Sum: " + sum);
        scanner.close();
    }
    
}
