/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */

public class foeac {
    public static void main(String[] args) {
        int[] numbers = {3, 7, 2, 9, 5, 1, 8};
        int max = findMax(numbers);
        if (max != Integer.MIN_VALUE) {
            System.out.println("Maximum value: " + max);
        } else {
            System.out.println("Array is empty.");
        }
    }

    /**
     * Returns the maximum value in an integer array using a for-each loop.
     * @param array the input array
     * @return the maximum value, or Integer.MIN_VALUE if the array is empty
     */
    public static int findMax(int[] array) {
        if (array == null || array.length == 0) {
            return Integer.MIN_VALUE; // or throw IllegalArgumentException
        }

        int max = array[0]; // initialize with first element
        for (int num : array) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }
}