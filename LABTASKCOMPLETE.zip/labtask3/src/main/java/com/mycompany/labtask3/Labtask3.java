/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
public class Labtask3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
