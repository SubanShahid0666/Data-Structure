/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
public class SkipMultiplesOfThree {
      public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {
            if (i % 3 == 0) {
                continue; // skip printing this number
            }
            System.out.print(i + " ");
        }
    }
    
}
