/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask3;

/**
 *
 * @author Suban Shahid Satti
 */
public class positive {
    public static void main(String[] args){
        
    
    int i=-5;
    do{
        System.out.println(i);
                i++;
    } 
    while(i<=0);
}
}
