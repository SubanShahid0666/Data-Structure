/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab4;

/**
 *
 * @author Suban Shahid Satti
 */
public class Rectangle {
     private double width;
    private double height;

    // Constructor
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    // Getters and Setters
    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    // Area method
    public double area() {
        return width * height;
    }

    // Perimeter method
    public double perimeter() {
        return 2 * (width + height);
    }

    // Optional: toString for easy printing
    @Override
    public String toString() {
        return "Rectangle{width=" + width + ", height=" + height + 
               ", area=" + area() + ", perimeter=" + perimeter() + "}";
    }

    // Test
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5.0, 3.0);
        System.out.println(rect);
        System.out.println("Area: " + rect.area());
        System.out.println("Perimeter: " + rect.perimeter());

        // Modify and test again
        rect.setWidth(7.5);
        rect.setHeight(4.2);
        System.out.println("\nAfter resize:");
        System.out.println(rect);
    }
    
}
