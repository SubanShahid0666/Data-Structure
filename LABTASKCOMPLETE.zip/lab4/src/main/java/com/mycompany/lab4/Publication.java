/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab4;

/**
 *
 * @author Suban Shahid Satti
 */
public class Publication {
     private String title;
    private String author;
    private double price;

    // Constructor
    public Publication(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Display methods
    public void displayPrice() {
        System.out.printf("Price: $%.2f%n", price);
    }

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        displayPrice();
    }

    // Update method with validation
    public void updatePrice(double newPrice) {
        if (newPrice < 0) {
            System.out.println("Error: Price cannot be negative.");
        } else {
            this.price = newPrice;
            System.out.println("Price updated successfully.");
        }
    }

    @Override
    public String toString() {
        return "Publication{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                '}';
    }

    // Test
    public static void main(String[] args) {
        Publication pub = new Publication("The Great Gatsby", "F. Scott Fitzgerald", 12.99);
        pub.displayDetails();
        pub.updatePrice(14.50);
        pub.displayPrice();
        pub.updatePrice(-5.00);
        System.out.println(pub);
    }
    
}
