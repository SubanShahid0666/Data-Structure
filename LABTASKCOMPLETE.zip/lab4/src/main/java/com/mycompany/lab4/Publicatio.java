/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab4;

/**
 *
 * @author Suban Shahid Satti
 */
public class Publicatio {
     private String title;
    private String author;
    private double price;

    // Constructor
    public Publicatio(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return "Publication{title='" + title + "', author='" + author + "', price=" + price + "}";
    }

    // Demonstration
    public static void main(String[] args) {
        Publication pub1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", 12.99);
        Publication pub2 = new Publication("1984", "George Orwell", 8.49);

        System.out.println("Initial state:");
        System.out.println("pub1: " + pub1);
        System.out.println("pub2: " + pub2);

        // Modify only pub1
        pub1.setPrice(14.99);
        pub2.setTitle("Nineteen Eighty-Four");

        System.out.println("\nAfter changes:");
        System.out.println("pub1: " + pub1);
        System.out.println("pub2: " + pub2);
    }
    
}
