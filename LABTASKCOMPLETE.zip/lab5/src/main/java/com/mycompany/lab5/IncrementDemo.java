/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab5;

/**
 *
 * @author Suban Shahid Satti
 */

public class IncrementDemo {
    public static void main(String[] args) {
        // Example 1
        int x = 5;
        int y = ++x + x++; // 6 + 6 = 12, final x=7
        System.out.println("Case 1: y=" + y + ", x=" + x); // y=12, x=7

        // Example 2
        x = 5;
        y = x++ + ++x; // 5 + 7 = 12, final x=7
        System.out.println("Case 2: y=" + y + ", x=" + x); // y=12, x=7

        // Example 3
        x = 3;
        y = ++x * x++; // 4 * 4 = 16, final x=5
        System.out.println("Case 3: y=" + y + ", x=" + x); // y=16, x=5

        // Example 4
        x = 3;
        y = x++ * ++x; // 3 * 5 = 15, final x=5
        System.out.println("Case 4: y=" + y + ", x=" + x); // y=15, x=5
    }
}
