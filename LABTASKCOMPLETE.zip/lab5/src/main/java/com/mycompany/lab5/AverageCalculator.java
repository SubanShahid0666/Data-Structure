/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab5;

/**
 *
 * @author Suban Shahid Satti
 */

import java.util.Scanner;

public class AverageCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read three integers
        System.out.print("Enter first integer: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter second integer: ");
        int num2 = scanner.nextInt();

        System.out.print("Enter third integer: ");
        int num3 = scanner.nextInt();

        // Calculate average as double
        double average = (num1 + num2 + num3) / 3.0; // 3.0 forces floating-point division
        // Alternatively: double average = (double)(num1 + num2 + num3) / 3;

        // Display with two decimal places
        System.out.printf("The average is: %.2f%n", average);
        // Or just: System.out.println("Average: " + average);
        // If you want more precision, use %f without formatting.

        scanner.close();
    }
}