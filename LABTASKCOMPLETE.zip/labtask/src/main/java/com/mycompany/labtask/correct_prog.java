/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask;

/**
 *
 * @author Suban Shahid Satti
 */
public class correct_prog {
    public static void main (String[] args){
       // float name="Suban";
       String name="Suban;";
       System.out.println("Name"+name);
               
    }
    
}
