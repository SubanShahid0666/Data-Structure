/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask;

/**
 *
 * @author Suban Shahid Satti
 */
public class artimatic {
    public static void main(String[] args){
              int a=9;
              int b=3;
              int sum=a+b;
              int product=a*b;
              int difference=a-b;
              int quotient=a/b;
              System.out.println("Sum: "+sum);
              System.out.println("Product: "+product);
              System.out.println("Difference: "+difference);
              System.out.println("Quotient: "+quotient);
    }
    
}
