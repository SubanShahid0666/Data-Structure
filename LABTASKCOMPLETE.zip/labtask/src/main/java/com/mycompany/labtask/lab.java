/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask;

/**
 *
 * @author Suban Shahid Satti
 */
public class lab {
    public static void main (String[] args){
       String name="Suban";
       int semester=3;
       int gpa=3;
       System.out.println("Name: "+name);
        System.out.println("Semester: "+semester);
         System.out.println("Cgpa: "+gpa);
       
    }
    
}
