/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask;

/**
 *
 * @author Suban Shahid Satti
 */

public class student {
    public static void main (String[] args){
        String name="Suban";
        String department="Data Science";
        int user_id=75988;
        int semester=3;
        int subject=5;
        System.out.println("Here is full data of student");
        System.out.println("Name: "+name);
        System.out.println("Department: "+department);
        System.out.println("User_id: "+user_id);
        System.out.println("Semester: "+semester);
        System.out.println("Subjects: "+subject);
        
        
    }
    
    
}
