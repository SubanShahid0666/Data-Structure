/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask2;

/**
 *
 * @author Suban Shahid Satti
 */
import java.util.Scanner;
public class largernumber {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of a");
        int  a= sc.nextInt();
        System.out.println("enter the value of b");
        int b=sc.nextInt();
        
       
        if(a>b){
            System.out.println( a+": is the largest number: ");
        }else
        {
            System.out.println(b+":  is the largest number");
        }
    }
    
}
