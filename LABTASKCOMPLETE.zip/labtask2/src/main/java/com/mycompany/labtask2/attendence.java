/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask2;

/**
 *
 * @author Suban Shahid Satti
 */
import java.util.Scanner;
public class attendence {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your marks");
        int marks=sc.nextInt();
        System.out.println("Enter your attendence percentage ");
        int attend=sc.nextInt();
        if(marks>50 && attend>50){
            System.out.println("Eliglible");
        }else{
            System.out.println("not Eliglible");
        }
    }
    
}
