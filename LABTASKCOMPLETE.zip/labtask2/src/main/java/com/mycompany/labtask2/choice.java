/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask2;

/**
 *
 * @author Suban Shahid Satti
 */
import java.util.Scanner;
public class choice {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter you choice from 1 to 7 number accordint to week days");
        int choice=sc.nextInt();
        switch(choice){
            case 1:
                System.out.println("monday is free");
                break;
            case 2:
                System.out.println("tuesday is free");
                break;
            case 3:
                System.out.println("wednesay is free");
                break;
            case 4:
                System.out.println("thursday is free");
                break;
            case 5:
                System.out.println("friday is free");
                break;
            case 6:
                System.out.println("saturday is free");
                break;
           case 7:
                System.out.println("sunday is free");
                break;
            
        }
    }
}
