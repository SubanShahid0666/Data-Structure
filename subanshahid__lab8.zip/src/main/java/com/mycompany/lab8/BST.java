/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab8;

/**
 *
 * @author suban
 */
class Node {
    int data; Node left, right;
    Node(int v) { data = v; }
}

// Changed this to public so it matches the file name "BST.java"
public class BST {
    Node root;

    Node insertRec(Node cur, int v) {
        if (cur == null) return new Node(v);
        if (v < cur.data)      cur.left  = insertRec(cur.left, v);
        else if (v > cur.data) cur.right = insertRec(cur.right, v);
        return cur;
    }
    void insert(int v) { root = insertRec(root, v); }

    void inorder(Node cur) {
        if (cur == null) return;
        inorder(cur.left);
        System.out.print(cur.data + " ");
        inorder(cur.right);
    }
    void preorder(Node cur) {
        if (cur == null) return;
        System.out.print(cur.data + " ");
        preorder(cur.left);
        preorder(cur.right);
    }
    void postorder(Node cur) {
        if (cur == null) return;
        postorder(cur.left);
        postorder(cur.right);
        System.out.print(cur.data + " ");
    }

    int findMin() {
        if (root == null) throw new IllegalStateException("Tree is empty");
        Node cur = root;
        while (cur.left != null) cur = cur.left;
        return cur.data;
    }
    int findMax() {
        if (root == null) throw new IllegalStateException("Tree is empty");
        Node cur = root;
        while (cur.right != null) cur = cur.right;
        return cur.data;
    }

    // Moved the main method inside the BST class
    public static void main(String[] args) {
        BST bst = new BST();
        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};
        for (int v : values) bst.insert(v);

        System.out.print("Inorder:   "); bst.inorder(bst.root);   System.out.println();
        System.out.print("Preorder:  "); bst.preorder(bst.root);  System.out.println();
        System.out.print("Postorder: "); bst.postorder(bst.root); System.out.println();
        System.out.println("Minimum: " + bst.findMin());
        System.out.println("Maximum: " + bst.findMax());
    }
}