import java.util.Scanner;
public class la{
    static int linerserch(int[] arr, int target){
        for (int i=0; i<arr.length;i++)
        {
            if(arr[i]==target){
                return i;
            }
    }
       return -1; 
    }
    static int binaryserch(int[] arr,int target){
        int low=0;
        int high=arr.length-1;
        while(low<=high){
            int middle=(low+high)/2;
        
        if(arr[middle]==target){
           return middle;
        }
            if (arr[middle]<target){
               low= middle+1;
            }
            else {
                high= middle-1;
            }
    }
    return -1;
    
    }
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        int[] binaryArray={12, 23, 34, 45, 56, 78, 89};
        int[] linerArray={45, 35, 12, 89, 56 ,78,23};
        System.out.println("enter a target valuee: " );
        int target=input.nextInt();
        int linearresult=linerserch(linerArray, target);
        int binaryresult=binaryserch(binaryArray, target);
        System.out.println("target values"+target);
        
        if(linearresult !=-1){
            System.out.println("liner serch found");
            System.out.println("index result out"+linearresult);
        }else{
            System.out.println("linear serch not found");
        }
        if (binaryresult !=-1){
            System.out.println("binary result found");
            System.out.println("binary index: "+binaryresult);
        }
        else{
            System.out.println("binary result not found");
        }
     
    }
        
    }
    
