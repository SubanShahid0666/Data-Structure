/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask4;

/**
 *
 * @author suban
 */
public class ava3 {

    static int[] queue = new int[5];
    static int front = 0;
    static int rear = -1;
    static int count = 0;

    static void enqueue(int value) {
        if (count == 5) {
            System.out.println("Queue Overflow");
        } else {
            rear++;
            queue[rear] = value;
            count++;
            System.out.println(value + " enqueued");
        }
    }

    static void dequeue() {
        if (count == 0) {
            System.out.println("Queue Underflow");
        } else {
            System.out.println(queue[front] + " dequeued");
            front++;
            count--;
        }
    }

    static void peek() {
        if (count == 0) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Front element: " + queue[front]);
        }
    }

    static void display() {
        if (count == 0) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Queue elements:");
            for (int i = front; i <= rear; i++) {
                System.out.println(queue[i]);
            }
        }
    }

    public static void main(String[] args) {

        enqueue(10);
        enqueue(20);
        enqueue(30);

        display();

        peek();

        dequeue();

        display();
    }
}
    

