/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Stack;

/**
 *
 * @author pc
 */
public class PrefixToInfix {


    public static String prefixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        // Read from right to left
        for (int i = expression.length() - 1; i >= 0; i--) {
            char ch = expression.charAt(i);

            if (ch == ' ') continue;

            // If operand, push onto stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            } 
            // If operator, pop two operands
            else {
                String left = stack.pop();   // first pop = left operand
                String right = stack.pop();  // second pop = right operand

                String combined = "(" + left + " " + ch + " " + right + ")";
                stack.push(combined);
            }
        }

        return stack.pop();
    }

    public static void main(String[] args) {
        String[] testExpressions = {
            "+ A * B C",
            "* + A B C",
            "- * A + B C D",
            "+ A B"
        };

        for (String expr : testExpressions) {
            System.out.println("Prefix Expression : " + expr);
            System.out.println("Infix Expression  : " + prefixToInfix(expr));
            System.out.println("----------------------------------------");
        }
    }
}
