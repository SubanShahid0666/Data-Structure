/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Stack;

/**
 *
 * @author pc
 */
public class InfixtoPrefix {


    // Returns precedence of operators
    public static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
            case '%':
                return 2;
            default:
                return -1;
        }
    }

    // Checks whether a character is an operand
    public static boolean isOperand(char ch) {
        return Character.isLetterOrDigit(ch);
    }

    // Converts modified infix (reversed & parentheses swapped) to postfix
    // Uses strict precedence (>) for right-associativity
    private static String infixToPostfixModified(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            if (ch == ' ') continue;

            if (isOperand(ch)) {
                result.append(ch).append(' ');
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(' ');
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                }
            } else {
                // Pop while top has strictly greater precedence
                while (!stack.isEmpty() && precedence(stack.peek()) > precedence(ch)) {
                    result.append(stack.pop()).append(' ');
                }
                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() != '(') {
                result.append(stack.pop()).append(' ');
            } else {
                stack.pop();
            }
        }

        return result.toString().trim();
    }

    // Main method to convert Infix to Prefix
    public static String infixToPrefix(String expression) {
        // Step 1: Remove spaces and reverse the infix expression
        String noSpaces = expression.replaceAll("\\s+", "");
        StringBuilder reversed = new StringBuilder(noSpaces).reverse();

        // Step 2: Swap '(' with ')' and vice versa
        for (int i = 0; i < reversed.length(); i++) {
            char ch = reversed.charAt(i);
            if (ch == '(') {
                reversed.setCharAt(i, ')');
            } else if (ch == ')') {
                reversed.setCharAt(i, '(');
            }
        }

        // Step 3: Convert modified expression to Postfix
        String postfix = infixToPostfixModified(reversed.toString());

        // Step 4: Reverse the Postfix to get Prefix
        String[] tokens = postfix.split("\\s+");
        StringBuilder prefix = new StringBuilder();
        for (int i = tokens.length - 1; i >= 0; i--) {
            prefix.append(tokens[i]);
            if (i > 0) prefix.append(' ');
        }

        return prefix.toString();
    }

    public static void main(String[] args) {
        String[] testExpressions = {
            "A + B * C",
            "(A + B) * C",
            "A * (B + C) - D",
            "A + B * C - D",
            "(A + B) * (C - D)"
        };

        for (String expression : testExpressions) {
            System.out.println("Infix Expression  : " + expression);
            System.out.println("Prefix Expression : " + infixToPrefix(expression));
            System.out.println("----------------------------------------");
        }
    }
}