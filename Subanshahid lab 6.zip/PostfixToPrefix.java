/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Stack;

/**
 *
 * @author pc
 */
public class PostfixToPrefix {


    public static String postfixToPrefix(String expression) {
        Stack<String> stack = new Stack<>();

        // Read from left to right
        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            if (ch == ' ') continue;

            // If operand, push onto stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            } 
            // If operator, pop two operands
            else {
                String right = stack.pop();  // first pop = right operand
                String left = stack.pop();   // second pop = left operand

                String combined = ch + " " + left + " " + right;
                stack.push(combined);
            }
        }

        return stack.pop();
    }

    public static void main(String[] args) {
        String[] testExpressions = {
            "A B C * +",
            "A B + C *",
            "A B C + * D -",
            "A B +"
        };

        for (String expr : testExpressions) {
            System.out.println("Postfix Expression : " + expr);
            System.out.println("Prefix Expression  : " + postfixToPrefix(expr));
            System.out.println("----------------------------------------");
        }
    }
}