/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
import java.util.Stack;

public class PostfixToInfix {

    // Converts a postfix expression to infix notation
    public static String postfixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            // Ignore spaces
            if (ch == ' ') {
                continue;
            }

            // If operand, push it onto the stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }
            // If operator, pop two operands and form an infix expression
            else {
                String right = stack.pop();   // first pop is right operand
                String left = stack.pop();    // second pop is left operand

                // Place operator between operands and enclose in parentheses
                String combined = "(" + left + " " + ch + " " + right + ")";
                stack.push(combined);
            }
        }

        // The final element in the stack is the required infix expression
        return stack.pop();
    }

    public static void main(String[] args) {
        // Test expressions (space-separated or without spaces, both work)
        String[] testExpressions = {
            "A B C * +",
            "A B + C *",
            "A B + C D - *",
            "A B * C +",
            "A B C + *"
        };

        for (String expression : testExpressions) {
            System.out.println("Postfix Expression : " + expression);
            System.out.println("Infix Expression   : " + postfixToInfix(expression));
            System.out.println("----------------------------------------");
        }
    }
}